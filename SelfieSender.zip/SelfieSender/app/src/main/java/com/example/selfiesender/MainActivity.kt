package com.example.selfiesender

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var photoUri: Uri
    private lateinit var currentPhotoPath: String

    private val REQUEST_IMAGE_CAPTURE = 1 //код щоб визначити результат від камери
    private val REQUEST_CAMERA_PERMISSION = 100 //код щоб перевірити дозвіл на камеру

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView = findViewById(R.id.imageView)
        val btnTakePhoto = findViewById<Button>(R.id.btnTakePhoto)
        val btnSendEmail = findViewById<Button>(R.id.btnSendEmail)

        btnTakePhoto.setOnClickListener {
            //запрошуємо дозвіл на камеру
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.CAMERA),
                    REQUEST_CAMERA_PERMISSION
                )
            } else {
                dispatchTakePictureIntent()
            }
        }

        btnSendEmail.setOnClickListener {
            sendEmailWithPhoto()
        }
    }

    private fun dispatchTakePictureIntent() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (intent.resolveActivity(packageManager) != null) { //
            //свторюємо файл куди буде збережене фото
            val photoFile = createImageFile()
            //через file provider отримуємо посилання uri на фото, як дозвіл на передавання файлу камері
            photoUri = FileProvider.getUriForFile(this, "${packageName}.provider", photoFile)
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri) //вказує куди зберігати створене фото
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivityForResult(intent, REQUEST_IMAGE_CAPTURE)
        }
    }

    private fun createImageFile(): File {
        // генерація унікального імені файлу яке включає дату та час
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "JPEG_${timeStamp}_"
        val storageDir = getExternalFilesDir("Pictures")
        val image = File.createTempFile(fileName, ".jpg", storageDir) //створюється jpg для збереження фото
        currentPhotoPath = image.absolutePath
        return image
    }

    //метод який показує фото на екрані, якщо воно вже зроблене успішно
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == Activity.RESULT_OK) {
            imageView.setImageURI(photoUri)
        }
    }

    //метод який відркиває камеру, якщо дозврлили доступ до камери
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                dispatchTakePictureIntent()
            } else {
                Toast.makeText(this, "Дозвіл на камеру не отримано", Toast.LENGTH_SHORT).show()
            }
        }
    }

    //метод що формує повідомлення разом з фото
    private fun sendEmailWithPhoto() {
        val emailIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_EMAIL, arrayOf("hodovychenko@op.edu.ua"))
            putExtra(Intent.EXTRA_SUBJECT, "ANDROID Снігур Аліна")
            putExtra(
                Intent.EXTRA_TEXT,
                "Ось моє селфі\n\nПосилання на репозиторій: https://github.com/snegurrochka/selfiesender"
            )
            // даємо дозволи іншим програмам читати наш файл
            putExtra(Intent.EXTRA_STREAM, photoUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        // відкриває менб де можна виюрати через яку програму надсилати листа
        if (emailIntent.resolveActivity(packageManager) != null) {
            startActivity(Intent.createChooser(emailIntent, "Send email..."))
        }
    }
}
